require('dotenv').config(); // variáveis de ambiente do arquivo .env
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
  dialect: 'postgres',
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD
});

// Adicione o modelo Tarefa ao sequelize
const Tarefa = require('./models/Tarefa'); 

// Sincroniza o modelo com o banco de dados
sequelize.sync({ force: false }) 
  .then(() => {
    console.log('Modelos sincronizados com o banco de dados');
  })
  .catch((err) => {
    console.error('Erro ao sincronizar modelos:', err);
  });

module.exports = {
  sequelize,
  Tarefa
};
