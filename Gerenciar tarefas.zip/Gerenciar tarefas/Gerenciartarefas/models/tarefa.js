const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Tarefa = sequelize.define('Tarefa', {
  nome: {
    type: DataTypes.STRING,
    allowNull: false
  },
  descricao: {
    type: DataTypes.TEXT
  },
  prioridade: {
    type: DataTypes.ENUM('baixa', 'média', 'alta'),
    defaultValue: 'baixa'
  },
  data_de_inicio: {
    type: DataTypes.DATE
  },
  data_de_termino: {
    type: DataTypes.DATE
  },
  concluido: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
});

module.exports = Tarefa;
