const express = require('express');
const { ApolloServer, gql } = require('apollo-server-express');
const sequelize = require('./database');
const Tarefa = require('./models/tarefa'); 
const { createWriteStream } = require('fs');

require('dotenv').config();

const path = require('path');

const typeDefs = gql`
  type Tarefa {  
    id: ID!
    nome: String!
    descricao: String
    prioridade: String
    data_de_inicio: String
    data_de_termino: String
    concluido: Boolean
  }

  type Query {
    tarefas: [Tarefa!]!
  }

  type Mutation {
    adicionarTarefa(nome: String!, descricao: String, prioridade: String, data_de_inicio: String, data_de_termino: String, concluido: Boolean): Tarefa!
  }
`;

const resolvers = {
  Query: {
    tarefas: async () => {
      return await Tarefa.findAll();
    }
  },
  Mutation: {
    adicionarTarefa: async (_, { nome, descricao, prioridade, data_de_inicio, data_de_termino, concluido }) => {
      try {
        const novaTarefa = await Tarefa.create({ nome, descricao, prioridade, data_de_inicio, data_de_termino, concluido });
        return novaTarefa;
      } catch (error) {
        throw new Error('Erro ao adicionar tarefa: ' + error.message);
      }
    }
  }
};

async function startServer() {
  const server = new ApolloServer({ typeDefs, resolvers });
  await server.start();

  const app = express();

  app.set('view engine', 'ejs');
  
  app.use(express.static('public'));
  app.use(express.static(path.join(__dirname, 'public')));

  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });

  app.get('/tarefas', async (req, res) => {  
    try {
      console.log(' Dados das tarefas do banco de dados...');
      const tarefas = await Tarefa.findAll();
      console.log('Tarefas encontradas:', tarefas);
      res.render('tarefas', { tarefas });
    } catch (error) {
      console.error('Erro ao buscar tarefas', error);
      res.status(500).send('Erro ao buscar tarefas');
    }
  });

  server.applyMiddleware({ app });

  await sequelize.sync({ alter: true });
  console.log('Tabelas sincronizadas com o banco de dados.');

  const PORT = process.env.PORT || 4005;
  app.listen(PORT, () =>
    console.log(`Servidor GraphQL rodando em http://localhost:${PORT}${server.graphqlPath}`)
  );
}

startServer().catch(error => console.error('Erro ao iniciar o servidor:', error));
