
CREATE TABLE tarefas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    prioridade VARCHAR(50),
    data_de_inicio DATE,
    data_de_termino DATE,
    concluido BOOLEAN
);



SELECT id, nome, descricao, prioridade, data_de_inicio, data_de_termino, concluido, "createdAt", "updatedAt"
FROM public."Tarefas";
